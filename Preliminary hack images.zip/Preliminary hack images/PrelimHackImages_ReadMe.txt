ReadMe == Preliminary hack images folder

This folder was created on 8 June 2016. It houses images that are/will be uploaded to github/3D seals 
as a showcase of the sorts of images in the full catalog.
Images inside are examples of ID challenges such as molt stage, pitch/yaw/roll, photo quality, wrinkled skin.

Images in the "Matches examples" folder are separated by folder. Each folder represents a unique individual 
with multiple photos from different days/photographers/locations.

A complete catalog will be uploaded to Git at a later date.